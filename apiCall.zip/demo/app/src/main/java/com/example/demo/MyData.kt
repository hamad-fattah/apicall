package com.example.demo

data class MyData(
    val code: String,
    val `data`: Any,
    val message: String,
    val my_dataItem: MyDataItem,
    val success: Boolean
)