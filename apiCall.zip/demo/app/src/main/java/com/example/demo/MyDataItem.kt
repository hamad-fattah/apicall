package com.example.demo

data class MyDataItem(
    val ended_at: String,
    val started_at: String
)